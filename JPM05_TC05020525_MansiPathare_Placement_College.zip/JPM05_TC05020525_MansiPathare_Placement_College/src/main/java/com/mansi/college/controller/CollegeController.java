package com.mansi.college.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.mansi.college.entity.College;
import com.mansi.college.service.CollegeService;
@RestController
@RequestMapping("/college")
public class CollegeController {
	@Autowired
	CollegeService collegeService;
	public CollegeService getCollegeService() {
		return collegeService;
	}

	public void setCollegeService(CollegeService collegeService) {
		this.collegeService = collegeService;
	}
	// http://localhost:8071/colleges/create - Post
	@PostMapping("/create")
	public College addCollege(@RequestBody College college)
	{
		return collegeService.save(college);
	}
	// http://localhost:8071/colleges/2 -GET
	@GetMapping(path="/{id}")
	public College getCollegeById(@PathVariable int id)
	{
		return collegeService.getCollegeById(id); 
	}
	//http://localhost:8071/colleges/id -PUT	
	@PutMapping(path="/{id}") 
	public College updateCollege(@RequestBody College college,@PathVariable int id)
	{
		return collegeService.update(id,college); 
	}
	//http://localhost:8071/colleges/2 -DELETE
	@DeleteMapping(path="/{id}")
	public String deletecollege(@PathVariable int id)
	{
		return collegeService.delete(id); 
	}	
	//http://localhost:8071/colleges GET
	@GetMapping
	public List<College> getAllCollege()
	{
		return collegeService.getClglist();	
		}
	

}

