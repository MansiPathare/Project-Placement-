package com.mansi.college.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="colleges")
public class College {
	@Id
	int id;
	String college_name;
	String college_admin;
	String location;
	public College() {
		super();
		// TODO Auto-generated constructor stub
	}
	public College(int id, String college_name,String college_admin,String location) {
		super();	
		this.id = id;
		this.college_name = college_name;
		this.college_admin = college_admin;
		this.location = location;	
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getCollege_admin() {

		return college_admin;
	}
	public void setCollege_admin(String college_admin) {
		this.college_admin = college_admin;
	}
	public String getlocation(){	
		return location;	
	}
	public void SetLocation(String location){
		this.location = location;
	}
	public void setLocation(String location) {
		// TODO Auto-generated method stub
		
	}
}


