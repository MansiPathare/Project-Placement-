package com.mansi.college.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mansi.college.entity.College;
import com.mansi.college.repository.CollegeRepository;
@Service
public class CollegeService {
	@Autowired
	CollegeRepository collegeRepository;
	public College save(College clg) {
		return collegeRepository.save(clg);
		}
	public College getCollegeById(int id) {
		return collegeRepository.findById(id).get();
		}
	public College update(int id,College college) {
		College clg=collegeRepository.findById(id).get();
		clg.setCollege_name(college.getCollege_name());
		clg.setCollege_admin(college.getCollege_admin());
		clg.setLocation(college.getlocation());
		return collegeRepository.save(clg); 
		}
	public String delete(int id)
	{
		collegeRepository.deleteById(id);
		return "Entity deleted" +id;
		}
	public List<College> getClglist()
	{
		return collegeRepository.findAll();
		}
	public CollegeRepository getCollegeRepository() {
		return collegeRepository;
		}
	public void setCollegeRepository(CollegeRepository collegeRepository) {
		this.collegeRepository = collegeRepository;
		}
	}

